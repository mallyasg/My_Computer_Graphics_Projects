Assignment #3: Ray tracing



FULL NAME: Ganesh Satish Mallya




MANDATORY FEATURES

------------------


Feature:                                 Status: finish? (yes/no)

-------------------------------------    -------------------------

1) Ray tracing triangles                  Yes


2) Ray tracing sphere                     Yes


3) Triangle Phong Shading                 Yes


4) Sphere Phong Shading                   Yes


5) Shadows rays                           Yes


6) Still images                           Yes

7) Extra Credit (up to 20 points)
  
        - Reflection of rays  from camera at the point of intersection
        - Recursive call of the trace function to implement reflections
        - Super sampling to imporve the quality of the image and remove aliasing
        effects
        - Soft shadow implementation, by modelling the light source as an area
        light source.
